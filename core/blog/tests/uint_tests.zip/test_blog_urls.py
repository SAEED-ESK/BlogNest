from django.test import SimpleTestCase
from django.urls import reverse, resolve
from ..views import BlogListView, BlogDetailView

class TestUrl(SimpleTestCase):

    def test_blog_post_list_url_resolve(self):
        url = reverse('blog:blog-list')
        self.assertEqual(resolve(url).func.view_class, BlogListView)

    def test_blog_post_detail_url_resolve(self):
        url = reverse('blog:blog-detail', kwargs={'pk': 1})
        self.assertEqual(resolve(url).func.view_class, BlogDetailView)