from django.test import TestCase
from datetime import datetime

from ..models import Post
from accounts.models import User, Profile


class TestModelPost(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            email='test@test.com', password='Zz#12345'
        )
        self.profile = Profile.objects.get(user=self.user)
        # self.profile = Profile.objects.create(
        #     user=self.user,
        #     first_name = 'test_first_name',
        #     last_name = 'test_last_name',
        #     description = 'test_desc',
        #     )

    def test_create_post_with_valid_data(self):
        post = Post.objects.create(
            author = self.profile,
            title = 'test',
            content ='description',
            category = None,
            status = True,
            published_date = datetime.now()
        )
        self.assertEqual(post.title, 'test')
        self.assertTrue(Post.objects.filter(pk=post.id).exists())