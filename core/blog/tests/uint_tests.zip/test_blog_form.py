from django.test import TestCase
from datetime import datetime

from ..models import Category
from ..forms import PostForm

class TestModelPost(TestCase):

    def test_model_post_with_valid_data(self):
        category_obj = Category.objects.create(name='hello')
        form = PostForm({
            'title': 'test',
            'content': 'description',
            'category': category_obj,
            'status': True,
            'published_date': datetime.now()
        })
        self.assertTrue(form.is_valid())

    def test_model_post_with_no_data(self):
        form = PostForm({})
        self.assertFalse(form.is_valid())