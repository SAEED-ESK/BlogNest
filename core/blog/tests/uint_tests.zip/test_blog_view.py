from django.test import TestCase, Client
from django.urls import reverse
from accounts.models import User,Profile
from datetime import datetime

from ..models import Post

class TestView(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(
            email='test@test.com', password='Zz#12345'
        )
        self.profile = Profile.objects.get(user=self.user)
        self.post = Post.objects.create(
            author = self.profile,
            title = 'test',
            content ='description',
            category = None,
            status = True,
            published_date = datetime.now()
        )

    def test_blog_post_list_url_successful_response(self):
        url = reverse('blog:blog-list')
        response = self.client.get(url)
        self.assertEquals(response.status_code, 200)
        self.assertTemplateUsed(response, template_name='blog/post_list.html')
        self.assertTrue(str(response.context).find('post'))

    def test_blog_post_detail_anonymouse_response(self):
        url = reverse('blog:blog-detail', kwargs={'pk':1})
        response = self.client.get(url)
        self.assertEquals(response.status_code, 302)