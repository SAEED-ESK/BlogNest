from django.core.management.base import BaseCommand
from faker import Faker

import random
import datetime

from accounts.models import User, Profile
from ...models import Post, Category

category_list = [
    'IT',
    'Fun',
    'Movie',
    'Photo'
]

class Command(BaseCommand):
    """
    A command for inserting 10 posts with random data
    and fake user and profile.
    """
    help = 'inserting dummy data'

    def __init__(self, *args, **kwargs):
        super(Command, self).__init__(*args, **kwargs)
        self.fake = Faker()

    def handle(self, *args, **options):
        user = User.objects.create_user(
            email=self.fake.email(), password='Zz@12345'
        )
        profile = Profile.objects.get(user=user)
        profile.first_name = self.fake.first_name()
        profile.last_name = self.fake.last_name()
        profile.description = self.fake.paragraph(nb_sentences=5)
        profile.save()

        for name in category_list:
            Category.objects.get_or_create(name=name)

        for _ in range(10):
            Post.objects.create(
                author = profile,
                title = self.fake.paragraph(nb_sentences=1),
                content = self.fake.paragraph(nb_sentences=5),
                category = Category.objects.get(name=random.choice(category_list)),
                status = random.choice([True, False]),
                published_date = datetime.datetime.now()
            )